The third line of the jupyter notebook file consists of a variable called `parent_folder_path`, which has the path of the parent folder, which consists of sub-folders and files of various types, such as PDF/docx/Image.

PROCEDURE TO RUN ON VARIOUS DATASETS
To Run Our Model on various datasets, copy the path of the folder and put it in the third line consisting of the variable `parent_folder_path.`

PROCEDURE TO COMPILE
To compile the jupyter notebook file, restart the kernel and re-run the whole notebook.